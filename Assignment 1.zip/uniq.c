#include "types.h"
#include "stat.h"
#include "user.h"

char buf[512000];
char *store;

void ignorecaseandduplicate(int fd, char *name){
	int i,n,k,z,count;
	char sprev[512];
	char prev[512];
	char spresent[512];
	char present[512];
	i=0;
	k=0;
	z=0;
	count=1;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		sprev[k] = buf[i];
	 		k++;
	 		i++;
		}
       }
	for (z = 0; z<strlen(sprev); z++) {
      		if(sprev[z] >= 'a' && sprev[z] <= 'z') {
         		prev[z] = sprev[z] - 32;
      		}
      		else {
			prev[z] = sprev[z];
		}
   	}
	
	i++;
	if(n>0){
    		while(i<n){
			k=0;
			memset(spresent,0,sizeof(spresent));
			while(buf[i]!='\n'){
	 			spresent[k] = buf[i];
	 			k++;
	 			i++;
			}
			memset(present,0,sizeof(present));
			for (z = 0; z<strlen(spresent); z++) {
      				if(spresent[z] >= 'a' && spresent[z] <= 'z') {
         				present[z] = spresent[z] - 32;
      				}
      				else {
					present[z] = spresent[z];
				}
   			}
			i++;
			if (strcmp(present,prev)==0){
				count++;
				if(count==2){
					printf(1,"%s\n",sprev);	
				} 
			}else{
				count=1;
				memset(prev,0,sizeof(prev));
				strcpy(prev,present);
				memset(sprev,0,sizeof(sprev));
				strcpy(sprev,spresent);
			}
       		}
     	}
}


void ignorecaseandcount(int fd, char *name)
{
	int i,n,k,z,count;
	char sprev[512];
	char prev[512];
	char spresent[512];
	char present[512];
	char value[512];
	count = 1;
	i=0;
	k=0;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		sprev[k] = buf[i];
	 		k++;
	 		i++;
		}
       	}
	for (z = 0; z<strlen(sprev); z++) {
      		if(sprev[z] >= 'a' && sprev[z] <= 'z') {
         		prev[z] = sprev[z] - 32;
      		}
      		else {
			prev[z] = sprev[z];
		}
   	}
	i++;
	if(n>0){
		
   		while(i<n){
			k=0;
			memset(spresent,0,sizeof(spresent));
			while(buf[i]!='\n'){
	 			spresent[k] = buf[i];
	 			k++;
	 			i++;
			}
			memset(present,0,sizeof(present));
			for (z = 0; z<strlen(spresent); z++){
    				if ((spresent[z] >= 'a') && (spresent[z] <= 'z')){ 
        				present[z] = spresent[z] - ('a' - 'A');
				}
				else {
					present[z] = spresent[z];
				}
   			}
			i++;
			if(strcmp(present,prev)==0){
				count++;
				if(count==2){
					memset(value,0,sizeof(value));
     					strcpy(value,sprev);	
				}
			}
			if(strcmp(present,prev)!=0){
				if(count>1){
					printf(1,"%d %s\n",count,value);
				}else{
					printf(1,"%d %s\n",count,sprev);
				}
				count = 1;
			}
     		memset(sprev,0,sizeof(sprev));
     		strcpy(sprev,spresent);
     		memset(prev,0,sizeof(prev));
     		strcpy(prev,present);
			       		
		}
		printf(1,"%d %s\n",count,value);
     	}
}




void printduplicate(int fd, char *name){
	int i,n,k,count;
	char prev[512];
	char curr[512];
	i=0;
	k=0;
	count=1;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		prev[k] = buf[i];
	 		k++;
	 		i++;
		}
       }
	i++;
	if(n>0){
    		while(i<n){
			k=0;
			memset(curr,0,sizeof(curr));
			while(buf[i]!='\n'){
	 			curr[k] = buf[i];
	 			k++;
	 			i++;
			}
			i++;
			if (strcmp(curr,prev)==0){
				count++;
				if(count==2){
					printf(1,"%s\n",curr);	
				} 
			}else{
				count=1;
				memset(prev,0,sizeof(prev));
				strcpy(prev,curr);
			}
       		}
     	}
}





void ignorecase(int fd, char *name)
{
	int i,n,k,z;
	char sprev[512];
	char prev[512];
	char spresent[512];
	char present[512];
	i=0;
	k=0;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		sprev[k] = buf[i];
	 		k++;
	 		i++;
		}
       	}
	for (z = 0; z<strlen(sprev); z++) {
      		if(sprev[z] >= 'a' && sprev[z] <= 'z') {
         		prev[z] = sprev[z] - 32;
      		}
      		else {
			prev[z] = sprev[z];
		}
   	}
	printf(1,"%s\n",sprev);
	i++;
	if(n>0){
   		while(i<n){
		k=0;
		memset(spresent,0,sizeof(spresent));
		while(buf[i]!='\n'){
	 		spresent[k] = buf[i];
	 		k++;
	 		i++;
		}
		memset(present,0,sizeof(present));
		for (z = 0; z<strlen(spresent); z++){
    			if ((spresent[z] >= 'a') && (spresent[z] <= 'z')){ 
        			present[z] = spresent[z] - ('a' - 'A');
			}
			else {
				present[z] = spresent[z];
			}
   		}
		i++;
		if(strcmp(present,prev)!=0){
			printf(1,"%s\n",spresent);
		}
     		memset(sprev,0,sizeof(sprev));
     		strcpy(sprev,spresent);
     		memset(prev,0,sizeof(prev));
     		strcpy(prev,present);
       		}
     	}
}


void uniqc(int fd, char *name)
{
	int i,n,k,count;
	char prev[512];
	char curr[512];
	i=0;
	k=0;
	count=1;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		prev[k] = buf[i];
	 		k++;
	 		i++;
		}
       }
	i++;
	if(n>0){
    		while(i<n){
			k=0;
			memset(curr,0,sizeof(curr));
			while(buf[i]!='\n'){
	 			curr[k] = buf[i];
	 			k++;
	 			i++;
			}
			i++;
			if (strcmp(curr,prev)==0){
				count++;
			}
			if(strcmp(curr,prev)!=0){
				printf(1,"%d %s\n",count,prev);
				count = 1;
				memset(prev,0,sizeof(prev));
				strcpy(prev,curr);
			}
      		}
    	}
	printf(1,"%d %s\n",count,prev);
}



void uniq(int fd, char *name)
{
	int i,n,k;
	char prev[512];
	char curr[512];
	i=0;
	k=0;
	n = read(fd, buf, sizeof(buf));
	if(n>0){
		while(buf[i]!='\n'){
	 		prev[k] = buf[i];
	 		k++;
	 		i++;
		}
       }
	printf(1,"%s\n",prev);
	i++;
	if(n>0){
    		while(i<n){
			k=0;
			memset(curr,0,sizeof(curr));
			while(buf[i]!='\n'){
	 		curr[k] = buf[i];
	 			k++;
	 			i++;
			}
			i++;
			if(strcmp(curr,prev)!=0){
				memset(prev,0,sizeof(prev));
				strcpy(prev,curr);
				printf(1,"%s\n",prev);
			}
      		}
     }
}


char *myarg[10];

int main(int argc, char *argv[])
{
	int fd, i,p;
   	int c =0;
	if(argc <= 1)
	  {
	    uniq(0, "");
	    exit();
	  }
	if(argc == 2)
	{
		for(p = 1; p < argc; p++)
		  {
		    if((fd = open(argv[p], 0)) < 0)
		    {
		      printf(1,"uniq: cannot open %s\n", argv[p]);
		      exit();
		    }
		    uniq(fd, argv[p]);
		    close(fd);
		    exit();
		  }

	}

  	for(i=1; i<argc-1;i++){
		myarg[c] = argv[i];
		c++;
	}
	if((fd = open(argv[argc-1], 0)) < 0){
      		printf(1, "uniq: cannot open %s\n", argv[i]);
      		exit();
    	}
   	/*
    	if(myarg[0]==0 && myarg[1]==0){
    		uniq(fd, argv[argc-1]);	
    		exit();
	}
	*/
    	if((strcmp(myarg[0],"-c")==0 && strcmp(myarg[1],"-i")==0) || (strcmp(myarg[0],"-i")==0 && strcmp(myarg[1],"-c")==0)) {
    		ignorecaseandcount(fd, argv[argc-1]);
	}
	else if((strcmp(myarg[0],"-i")==0 && strcmp(myarg[1],"-d")==0) || (strcmp(myarg[0],"-d")==0 && strcmp(myarg[1],"-i")==0))
	{
		ignorecaseandduplicate(fd, argv[argc-1]);
	}
    	else if(strcmp(myarg[0],"-c")==0 && (myarg[1]==0) ){
    		uniqc(fd, argv[argc-1]);
	}
   	else if(strcmp(myarg[0],"-i")==0 && (myarg[1]==0)){
    		ignorecase(fd, argv[argc-1]);
	}
   	else if(strcmp(myarg[0],"-d")==0 && (myarg[1]==0)){
    		printduplicate(fd, argv[argc-1]);
	}
   	else{
    		printf(1,"incorrect command\n");
	}

  	exit();
}