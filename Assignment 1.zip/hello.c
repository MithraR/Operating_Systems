#include "types.h"
#include "user.h"
#include "stat.h"
    
    
int main() 
{ 
  printf(1, "Hello world!!!!!\n"); 
  exit(); 
} 